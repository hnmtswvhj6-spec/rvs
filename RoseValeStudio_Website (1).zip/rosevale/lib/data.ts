// ─── Portfolio Data ───────────────────────────────────────────────────────────
// Replace placeholder images with your actual image paths under /public/portfolio/

export type PortfolioCategory =
  | 'Commercial Murals'
  | 'Cafés & Hospitality'
  | 'Fine Art'
  | 'Community Spaces'
  | 'Concepts';

export interface PortfolioItem {
  id: string;
  title: string;
  client: string;
  category: PortfolioCategory;
  location: string;
  year: number;
  description: string;
  highlights: string[];
  coverColor: string; // placeholder bg color until real image is added
  span?: 'wide' | 'tall' | 'normal';
}

export const portfolioItems: PortfolioItem[] = [
  {
    id: 'big-toy-shop',
    title: 'Typography Mural',
    client: 'Big Toy Shop',
    category: 'Commercial Murals',
    location: 'Edmonton, AB',
    year: 2026,
    description: 'A bold 10×10 ft hand-lettered typography mural celebrating the spirit and personality of Big Toy Shop. Designed by the client, executed by Rose Vale Studio.',
    highlights: ['10 × 10 ft interior mural', 'Hand-lettered typography', 'Client-designed artwork'],
    coverColor: '#D4C5B8',
    span: 'wide',
  },
  {
    id: 'botanical-cafe',
    title: 'Botanical Garden Mural',
    client: 'Placeholder Café',
    category: 'Cafés & Hospitality',
    location: 'Edmonton, AB',
    year: 2025,
    description: 'A floor-to-ceiling botanical mural transforming a café dining wall into an immersive garden experience. Lush ferns, trailing botanicals, and soft light define the space.',
    highlights: ['8 × 14 ft interior mural', 'Multi-panel composition', 'Custom palette matched to interior'],
    coverColor: '#B8C9B0',
    span: 'tall',
  },
  {
    id: 'prairie-fine-art',
    title: 'Prairie Gold Series',
    client: 'Private Commission',
    category: 'Fine Art',
    location: 'Edmonton, AB',
    year: 2025,
    description: 'A series of three large-format oil paintings capturing the quiet drama of Alberta prairies at harvest. Golden hour light across rolling grain fields.',
    highlights: ['Set of 3, 24×36 in each', 'Oil on linen', 'Available as prints'],
    coverColor: '#D9C99A',
  },
  {
    id: 'niche-climbing',
    title: 'Wilderness Wall',
    client: 'Niche Climbing',
    category: 'Commercial Murals',
    location: 'Edmonton, AB',
    year: 2026,
    description: 'A dramatic alpine landscape mural for a boutique climbing gym — jagged peaks, pine silhouettes, and a moody dusk sky that pulls climbers into the outdoors.',
    highlights: ['20 × 10 ft feature wall', 'Atmospheric perspective painting', 'Custom colour-matched to gym branding'],
    coverColor: '#8EA5B8',
    span: 'wide',
  },
  {
    id: 'community-mural',
    title: 'Roots & Rivers',
    client: 'Edmonton Community Foundation (Placeholder)',
    category: 'Community Spaces',
    location: 'Edmonton, AB',
    year: 2024,
    description: 'A 40-foot exterior mural celebrating Edmonton's river valley and multicultural community. Designed in partnership with local residents and completed in two weeks.',
    highlights: ['40 × 12 ft exterior mural', 'Community co-design process', 'Weather-resistant exterior paint'],
    coverColor: '#C4B8A8',
    span: 'wide',
  },
  {
    id: 'floral-commission',
    title: 'Garden Study No. 4',
    client: 'Private Residential',
    category: 'Fine Art',
    location: 'St. Albert, AB',
    year: 2024,
    description: 'A large-format floral study in soft oils — peonies, garden roses, and trailing clematis rendered in a loose, luminous style for a private dining room.',
    highlights: ['36 × 48 in oil on canvas', 'Custom commission', 'Framed and installed'],
    coverColor: '#D4B8C0',
  },
  {
    id: 'hotel-concept',
    title: 'River Valley Suite',
    client: 'Concept Proposal',
    category: 'Concepts',
    location: 'Edmonton, AB',
    year: 2025,
    description: 'A concept mural proposal for a boutique hotel suite — a panoramic North Saskatchewan river valley at dusk, wrapping three walls in a continuous landscape.',
    highlights: ['Full room wrap concept', '3-wall panoramic composition', 'Digital mockup & painted sample'],
    coverColor: '#A8B8C4',
  },
  {
    id: 'rockies-series',
    title: 'Rocky Mountain Series',
    client: 'Private Commission',
    category: 'Fine Art',
    location: 'Canmore, AB',
    year: 2024,
    description: 'Five intimate oil studies of the Rockies — Moraine Lake, Lake Louise, and the Icefields Parkway — painted en plein air and refined in studio.',
    highlights: ['5-piece series, 12×16 in each', 'Plein air oil studies', 'Framed in raw oak'],
    coverColor: '#B0BAC8',
  },
];

// ─── Services Data ────────────────────────────────────────────────────────────
export interface Service {
  id: string;
  title: string;
  for: string;
  description: string;
  includes: string[];
  starting: string;
}

export const services: Service[] = [
  {
    id: 'murals',
    title: 'Custom Murals',
    for: 'Businesses, cafés, restaurants, hotels, gyms, and retail spaces',
    description: 'Hand-painted murals that transform plain walls into defining features of your space. Every mural is original, designed for your environment, and built to last.',
    includes: ['Site consultation & wall assessment', 'Custom concept development', 'Design mockup & revisions', 'Full on-site painting', 'Protective sealing (where applicable)', 'Portfolio documentation'],
    starting: 'Priced by project scope & size',
  },
  {
    id: 'fine-art',
    title: 'Fine Art Commissions',
    for: 'Private collectors, residential clients, and corporate art buyers',
    description: 'Original paintings commissioned to your brief — whether a portrait of a beloved landscape, a botanical study for a dining room, or a series for a new home.',
    includes: ['Discovery conversation & mood board', 'Preliminary sketches', 'Work-in-progress updates', 'Oil or acrylic on canvas or linen', 'Professional framing options', 'Delivery & installation coordination'],
    starting: 'From $600 CAD',
  },
  {
    id: 'commercial',
    title: 'Commercial Artwork',
    for: 'Developers, hotels, healthcare spaces, and corporate offices',
    description: 'Large-scale artwork programs for commercial properties — from lobby feature walls to multi-room art collections. Managed professionally from brief to installation.',
    includes: ['Site walk & space analysis', 'Art direction & concept presentation', 'Scalable production (single piece or series)', 'Coordination with interior designers', 'Installation management', 'Certificate of authenticity'],
    starting: 'Priced by project',
  },
  {
    id: 'consulting',
    title: 'Art Consulting & Concept Development',
    for: 'Interior designers, developers, and businesses planning a renovation or new build',
    description: 'Not sure what you need, but you know your space needs art? Rose Vale Studio can help you develop a vision — sourcing, commissioning, and curating artwork that fits your brand, budget, and space.',
    includes: ['Space & brand discovery session', 'Concept direction & mood boards', 'Artist sourcing & project management', 'Budget planning', 'Procurement & installation coordination'],
    starting: 'From $400 CAD / session',
  },
];

// ─── Process Steps ────────────────────────────────────────────────────────────
export const processSteps = [
  {
    number: '01',
    title: 'Inquiry',
    description: 'Fill out the project inquiry form or send an email. Share what you\'re envisioning — even a rough idea is enough to start.',
  },
  {
    number: '02',
    title: 'Discovery Call',
    description: 'A short call to understand your space, your goals, your audience, and any existing design direction. No pressure, just conversation.',
  },
  {
    number: '03',
    title: 'Concept Direction',
    description: 'Based on our conversation, I\'ll develop a concept direction — style, palette, composition — for your review and input before any design begins.',
  },
  {
    number: '04',
    title: 'Design Proposal',
    description: 'A full design proposal with mockups showing the artwork in your actual space. Revisions are included until you\'re confident in the direction.',
  },
  {
    number: '05',
    title: 'Painting & Production',
    description: 'On-site painting executed with professional care and precision. You\'ll receive progress updates throughout, and I\'ll keep your space as clean as I found it.',
  },
  {
    number: '06',
    title: 'Final Reveal',
    description: 'A final walkthrough together. Once you\'re happy, I\'ll document the completed work, clear the site, and make any final touch-ups needed.',
  },
];
