# Rose Vale Studio — Website

Built with Next.js 14, TypeScript, and Tailwind CSS.

---

## Running Locally

```bash
# 1. Install dependencies
npm install

# 2. Run the development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## Where to Edit Things

### Content & Copy
- **All portfolio items** → `lib/data.ts` → `portfolioItems` array
- **All services** → `lib/data.ts` → `services` array
- **Process steps** → `lib/data.ts` → `processSteps` array
- **Homepage text** → `app/page.tsx`
- **About bio** → `app/about/page.tsx`

### Images
Every placeholder image is a coloured `<div>` with a TODO comment above it.
To add your real photos:

1. Drop images in `public/portfolio/` (e.g. `big-toy-shop.jpg`)
2. Add `import Image from 'next/image'` to the file
3. Replace the `<div style={{ backgroundColor: ... }}>` block with:
   ```jsx
   <Image
     src="/portfolio/big-toy-shop.jpg"
     alt="Big Toy Shop typography mural"
     fill
     className="object-cover"
   />
   ```
   (Wrap the `<Image>` in a `relative` container)

### Social Links
- Footer Instagram link → `components/Footer.tsx` → line with `href="https://instagram.com/"`
- Replace with `https://instagram.com/YOURHANDLE`

### Contact Form
The form currently logs to console. To actually receive submissions:

**Option A — Formspree (easiest, free tier available):**
1. Create account at formspree.io
2. Get your form endpoint (e.g. `https://formspree.io/f/XXXXXXXX`)
3. In `app/contact/page.tsx`, replace `handleSubmit` with:
   ```js
   const res = await fetch('https://formspree.io/f/XXXXXXXX', {
     method: 'POST',
     headers: { 'Content-Type': 'application/json' },
     body: JSON.stringify(Object.fromEntries(new FormData(e.currentTarget))),
   });
   if (res.ok) setSubmitted(true);
   ```

**Option B — Next.js API route + Resend:**
Create `app/api/contact/route.ts` and use the Resend SDK to email `studiorosevale@gmail.com`.

### Testimonials
Find the placeholder testimonial block in `app/page.tsx` (search for "TODO: Replace with a real client testimonial") and swap in a real quote.

### SEO / Metadata
Each page has its own `export const metadata` block at the top. Edit the `title` and `description` fields for each page.

---

## Deployment

Recommended: **Vercel** (free tier, native Next.js support)

1. Push this folder to a GitHub repo
2. Connect the repo at vercel.com
3. Deploy — no config needed

Or connect your existing Squarespace domain to Vercel after deploying.

---

## Tech Stack

| Tool | Version | Purpose |
|------|---------|---------|
| Next.js | 14 | Framework |
| TypeScript | 5 | Type safety |
| Tailwind CSS | 3 | Styling |
| Google Fonts | — | Cormorant Garamond + DM Sans |

