import type { Metadata } from 'next';
import './globals.css';
import Nav from '@/components/Nav';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: {
    default: 'Rose Vale Studio — Murals & Fine Art · Edmonton, AB',
    template: '%s | Rose Vale Studio',
  },
  description:
    'Rose Vale Studio creates nature-inspired murals and fine art for businesses, cafés, homes, and community spaces in Edmonton and beyond. Work with Kaitlyn Riesen.',
  openGraph: {
    siteName: 'Rose Vale Studio',
    locale: 'en_CA',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Nav />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
