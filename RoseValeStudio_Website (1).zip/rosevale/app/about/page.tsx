import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'About — Kaitlyn Riesen & Rose Vale Studio',
  description: 'Edmonton-based artist Kaitlyn Riesen creates nature-inspired murals and fine art for meaningful spaces — businesses, cafés, homes, and community projects.',
};

export default function About() {
  return (
    <>
      {/* Hero */}
      <section className="pt-32 pb-0 bg-ivory">
        <div className="container-max">
          <div className="grid md:grid-cols-2 gap-12 md:gap-20 items-end pb-16 border-b border-taupe">
            <div>
              <p className="label text-umber mb-4">The Artist</p>
              <h1 className="font-serif text-display-sm text-brown-deep">
                Kaitlyn Riesen
              </h1>
            </div>
            <div>
              {/* TODO: Replace with a portrait photo of Kaitlyn */}
              <div className="aspect-[4/5] bg-taupe flex items-end p-6">
                <span className="label text-umber/50">Artist portrait — add your photo here</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Bio */}
      <section className="section-pad bg-ivory">
        <div className="container-max grid md:grid-cols-12 gap-12">
          <div className="md:col-span-7 space-y-6 text-brown-mid font-light leading-relaxed text-lg">
            <p>
              Rose Vale Studio is a fine art and mural practice based in Edmonton, Alberta, created and run by artist Kaitlyn Riesen. For the past two years, Kaitlyn has been building a body of work that finds its roots in the natural world — the quiet drama of Alberta prairies, the weight of the Rockies, the delicate architecture of a garden in full bloom.
            </p>
            <p>
              Her work is defined by warmth and intention. Whether she's working at the scale of a fine art painting or a 40-foot exterior wall, the goal is the same: to make a space feel alive, to give it a story, to create something that earns a long second look.
            </p>
            <p>
              Kaitlyn works with businesses, cafés, hotels, community organizations, and private clients across Edmonton and Alberta. She's as comfortable navigating the particular needs of a commercial project — brand alignment, professional timelines, contractor coordination — as she is working with a residential client on a deeply personal commission.
            </p>
            <p>
              The name Rose Vale Studio reflects a commitment to beauty in the everyday: to artwork that doesn't ask to be admired from a distance, but that earns its place in the rooms where people actually live and work.
            </p>
          </div>

          <div className="md:col-span-4 md:col-start-9 space-y-8">
            {/* Studio Details */}
            <div className="bg-taupe p-7">
              <p className="label text-umber mb-5">Studio Details</p>
              <div className="space-y-4 text-sm text-brown-mid font-light">
                <div>
                  <p className="font-medium text-brown-deep">Location</p>
                  <p>Edmonton, Alberta</p>
                </div>
                <div>
                  <p className="font-medium text-brown-deep">Services</p>
                  <p>Murals · Fine Art · Commissions · Art Consulting</p>
                </div>
                <div>
                  <p className="font-medium text-brown-deep">Available For</p>
                  <p>Edmonton & surrounding area, with travel across Alberta</p>
                </div>
                <div>
                  <p className="font-medium text-brown-deep">Contact</p>
                  <a href="mailto:studiorosevale@gmail.com" className="text-umber hover:text-brown-deep transition-colors">studiorosevale@gmail.com</a>
                </div>
              </div>
            </div>

            {/* Inspiration */}
            <div>
              <p className="label text-umber mb-4">Draws Inspiration From</p>
              <div className="flex flex-wrap gap-2">
                {['Alberta prairies', 'Wildflowers & botanicals', 'Rocky Mountains', 'Natural light', 'Heritage interiors', 'Seasonal colour', 'Prairie skies', 'Canadian wilderness'].map(tag => (
                  <span key={tag} className="text-xs text-brown-mid border border-taupe px-3 py-1.5 font-light">{tag}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Studio Values */}
      <section className="py-16 bg-taupe">
        <div className="container-max grid sm:grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { value: 'Original', detail: 'Every piece of work is made from scratch for the specific space, client, and moment.' },
            { value: 'Collaborative', detail: 'The best outcomes come from listening well and building on your vision, not replacing it.' },
            { value: 'Rigorous', detail: 'Professional timelines, clear communication, and finished work that holds up over years.' },
            { value: 'Rooted', detail: 'Art that draws from real places, real light, and real landscapes — not from stock imagery or trend.' },
          ].map(({ value, detail }) => (
            <div key={value}>
              <p className="font-serif text-xl text-brown-deep mb-2">{value}</p>
              <p className="text-sm text-brown-mid font-light leading-relaxed">{detail}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Image placeholder row */}
      <section className="py-4 bg-ivory">
        <div className="container-max grid grid-cols-3 gap-3">
          {['#D4C5B8', '#B8C9B0', '#D9C99A'].map((color, i) => (
            <div key={i} className="aspect-[4/3]" style={{ backgroundColor: color }}>
              {/* TODO: Add studio / work-in-progress photos here */}
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-ivory text-center border-t border-taupe">
        <div className="container-max max-w-xl">
          <h2 className="font-serif text-3xl text-brown-deep mb-4">Let's work together.</h2>
          <p className="text-brown-mid font-light mb-8">Mural inquiries, fine art commissions, and art consulting — all starting with a simple conversation.</p>
          <div className="flex justify-center gap-4 flex-wrap">
            <Link href="/contact" className="btn-primary">Start a Project</Link>
            <Link href="/portfolio" className="btn-outline">View Portfolio</Link>
          </div>
        </div>
      </section>
    </>
  );
}
